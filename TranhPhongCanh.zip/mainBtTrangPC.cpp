#include <graphics.h>
#include <conio.h>
#include <stdlib.h>
#include <dos.h>

void veMatTroi(int x, int y) {
    setcolor(YELLOW);
    setfillstyle(SOLID_FILL, YELLOW);
    fillellipse(x, y, 40, 40);
    setcolor(LIGHTRED);
    circle(x, y, 50);
    circle(x, y, 60);
    circle(x, y, 70);
}

void veTroi() {
    setcolor(LIGHTBLUE);
    setfillstyle(SOLID_FILL, LIGHTBLUE);
    rectangle(0, 0, 640, 480);
    floodfill(1, 1, LIGHTBLUE);
}

void veDat() {
    setcolor(GREEN);
    setfillstyle(SOLID_FILL, GREEN);
    rectangle(0, 300, 640, 480);
    floodfill(1, 301, GREEN);
}

void veAo() {
    setcolor(CYAN);
    setfillstyle(SOLID_FILL, CYAN);
    fillellipse(320, 400, 170, 30);
}

void veBuiCo(int x, int y, float scale, int mau) {
    setcolor(mau);
    setfillstyle(SOLID_FILL, mau);
    int buiCoY = y - 10 * scale;
    fillellipse(x, buiCoY, 30 * scale, 25 * scale);
    fillellipse(x - 20 * scale, buiCoY + 5 * scale, 25 * scale, 20 * scale);
    fillellipse(x + 20 * scale, buiCoY + 5 * scale, 25 * scale, 20 * scale);
}

void veMay(int x, int y) {
    setcolor(WHITE);
    setfillstyle(SOLID_FILL, WHITE);
    fillellipse(x, y, 30, 20);
    fillellipse(x + 25, y - 10, 30, 20);
    fillellipse(x + 50, y, 30, 20);
}

void veCay(int x, int y, float scale) {
    setcolor(BROWN);
    setfillstyle(SOLID_FILL, BROWN);
    rectangle(x - 10 * scale, y, x + 10 * scale, y + 50 * scale);
    floodfill(x, y + 10 * scale, BROWN);
    setcolor(LIGHTGREEN);
    setfillstyle(SOLID_FILL, LIGHTGREEN);
    int tanCayY = y - 10 * scale;
    fillellipse(x, tanCayY, 30 * scale, 25 * scale);
    fillellipse(x - 20 * scale, tanCayY + 5 * scale, 25 * scale, 20 * scale);
    fillellipse(x + 20 * scale, tanCayY + 5 * scale, 25 * scale, 20 * scale);
}

void chuyenDongMay() {
    int x1 = 50, y1 = 100, dx1 = 2;
    int x2 = 200, y2 = 80, dx2 = 3;
    int x3 = 400, y3 = 120, dx3 = 2;
    while (!kbhit()) {
    	
        setactivepage(1);
        cleardevice();
        
        veTroi();
        
        veMatTroi(100, 80);
        
        veDat();
        
        veAo();
        
        veBuiCo(80, 400, 1.5, LIGHTGREEN);
        veBuiCo(590, 440, 0.5, LIGHTGREEN);
        veBuiCo(400, 420, 0.8, LIGHTGREEN);
        veBuiCo(500, 430, 0.5, 14); // B?i c? m�u cam
        
        veCay(100, 280, 1.2);
        veCay(200, 270, 1.5);
        veCay(300, 250, 2.0);
        veCay(400, 280, 1.3);
        veCay(550, 260, 1.8);
        
        veMay(x1, y1);
        veMay(x2, y2);
        veMay(x3, y3);
        
        delay(30);
        
        x1 += dx1;
        if (x1 > getmaxx() - 80 || x1 < 0) dx1 = -dx1;
        x2 += dx2;
        if (x2 > getmaxx() - 80 || x2 < 0) dx2 = -dx2;
        x3 += dx3;
        if (x3 > getmaxx() - 80 || x3 < 0) dx3 = -dx3;
        setvisualpage(1);
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, NULL);
    chuyenDongMay();
    getch();
    closegraph();
    return 0;
}

