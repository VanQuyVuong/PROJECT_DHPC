#include <graphics.h>
#include <math.h>
#include <conio.h>

#define PI 3.14159265

void veDoThiSin() {
    int midX = getmaxx() / 2, midY = getmaxy() / 2;
    int scaleX = 50, scaleY = 100; 

    line(0, midY, getmaxx(), midY);  
    line(midX, 0, midX, getmaxy());  

    for (int x = -midX; x < midX; x++) {
        int y = midY - sin(x * PI / 180) * scaleY;
        putpixel(midX + x, y, YELLOW);
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, NULL);
    
    veDoThiSin();

    getch();
    closegraph();
    return 0;
}

